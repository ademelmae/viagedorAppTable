namespace viagedorApp.Models
{
    public class Person
    {
        public int ID {get; set;}
        public string Fullname {get; set;}
    }
}