﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using viagedorApp.Models;

namespace viagedorApp.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        List<Person> List = new List<Person>();

        Person p1 = new Person();
        p1.ID = 1;
        p1.Fullname = "Ademel";

        Person p2 = new Person();
        p2.ID = 2;
        p2.Fullname = "Mae";

        Person p3 = new Person();
        p3.ID = 3;
        p3.Fullname = "Viagedor";

        List.Add(p1);
        List.Add(p2);
        List.Add(p3);
        return View(List);
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
